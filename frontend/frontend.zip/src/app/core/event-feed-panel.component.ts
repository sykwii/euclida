import { CommonModule, DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../features/auth/auth.service';
import { EventLog } from '../features/event-logs/event-logs.service';
import { EventFeedMode, EventFeedService, EventGroup, EventPriority } from './event-feed.service';

@Component({
  selector: 'app-event-feed-panel',
  standalone: true,
  imports: [CommonModule, DatePipe, FormsModule],
  template: `
    <aside class="nf-root" *ngIf="canSeeEvents" [class.is-open]="open">
      <button type="button" class="nf-toggle" *ngIf="!open" (click)="openPanel()" aria-label="Відкрити центр повідомлень">
        <span class="nf-toggle-main">
          <b>Центр повідомлень</b>
          <small>{{ stats.critical }} крит. · {{ stats.today }} сьогодні</small>
        </span>
        <strong [class.is-muted]="stats.unread === 0">{{ stats.unread }}</strong>
      </button>

      <section class="nf-panel" *ngIf="open" aria-label="Центр повідомлень">
        <header class="nf-header">
          <div>
            <span>{{ modeEyebrow }}</span>
            <h2>{{ modeTitle }}</h2>
          </div>
          <button type="button" class="nf-close" (click)="close($event)" aria-label="Закрити">×</button>
        </header>

        <section class="nf-summary">
          <button type="button" (click)="setMode('notifications')" [class.active]="mode === 'notifications'">
            <b>{{ stats.unread }}</b>
            <span>Нових</span>
          </button>
          <button type="button" (click)="setPriorityFilter('critical')" [class.active]="priorityFilter === 'critical'">
            <b>{{ stats.critical }}</b>
            <span>Критичних</span>
          </button>
          <button type="button" (click)="setMode('today')" [class.active]="mode === 'today'">
            <b>{{ stats.today }}</b>
            <span>Сьогодні</span>
          </button>
          <button type="button" (click)="setMode('journal')" [class.active]="mode === 'journal'">
            <b>{{ stats.journal }}</b>
            <span>Журнал</span>
          </button>
        </section>

        <section class="nf-toolbar">
          <div class="nf-tabs">
            <button type="button" [class.active]="mode === 'notifications'" (click)="setMode('notifications')">Центр</button>
            <button type="button" [class.active]="mode === 'today'" (click)="setMode('today')">Сьогодні</button>
            <button type="button" [class.active]="mode === 'journal'" (click)="setMode('journal')">Журнал</button>
          </div>

          <input type="search" placeholder="Пошук по ВГЗ, ВП, підрозділу, дії..." [(ngModel)]="searchTerm" />

          <div class="nf-filters">
            <button type="button" [class.active]="priorityFilter === 'all'" (click)="setPriorityFilter('all')">Всі</button>
            <button type="button" [class.active]="priorityFilter === 'critical'" (click)="setPriorityFilter('critical')">Критичні</button>
            <button type="button" [class.active]="priorityFilter === 'high'" (click)="setPriorityFilter('high')">Високі</button>
            <button type="button" [class.active]="unreadOnly" (click)="toggleUnreadOnly()" *ngIf="mode === 'notifications'">Непрочитані</button>
          </div>
        </section>

        <section class="nf-actions">
          <button type="button" (click)="expandPriority()" *ngIf="filteredGroups.length">Розкрити важливі</button>
          <button type="button" (click)="collapseAll()" *ngIf="filteredGroups.length">Згорнути</button>
          <button type="button" (click)="markSeen()" *ngIf="mode === 'notifications'">Прочитано</button>
          <button type="button" (click)="eventFeed.load()">Оновити</button>
          <button type="button" (click)="resetFilters()" *ngIf="hasFilters">Скинути</button>
        </section>

        <p class="nf-state" *ngIf="eventFeed.isLoading">Оновлюю події…</p>
        <section class="nf-state is-error" *ngIf="eventFeed.errorMessage && !eventFeed.isLoading">
          <span>{{ eventFeed.errorMessage }}</span>
          <button type="button" (click)="eventFeed.load()">Повторити</button>
        </section>

        <section class="nf-list">
          <article class="nf-group" *ngFor="let group of filteredGroups; trackBy: trackGroup" [ngClass]="[group.priority, group.tone, group.unreadCount > 0 ? 'is-unread' : '']">
            <button type="button" class="nf-group-head" (click)="toggleGroup(group.key)">
              <span class="nf-severity">{{ priorityLabel(group.priority) }}</span>
              <span class="nf-group-body">
                <strong>{{ group.title }}</strong>
                <small>{{ group.unitName || 'Без підрозділу' }} · {{ group.latestAt | date:'dd.MM HH:mm' }}</small>
                <em>{{ group.summary }}</em>
              </span>
              <span class="nf-group-count">
                <b>{{ group.items.length }}</b>
                <i *ngIf="group.unreadCount > 0">+{{ group.unreadCount }}</i>
                <small>{{ isOpen(group.key) ? '−' : '+' }}</small>
              </span>
            </button>

            <div class="nf-events" *ngIf="isOpen(group.key)">
              <button type="button" class="nf-event" *ngFor="let event of group.items; trackBy: trackEvent" [class.is-unread]="eventFeed.isUnread(event)" (click)="openEvent(event)">
                <span>
                  <strong>{{ event.entityName || event.title }}</strong>
                  <small>{{ event.createdAt | date:'HH:mm:ss' }}</small>
                </span>
                <p>{{ event.details || event.title }}</p>
                <em>{{ event.actorName || event.actorLogin || 'Система' }} · {{ eventFeed.getEventActionLabel(event) }}</em>
              </button>
            </div>
          </article>

          <p class="nf-empty" *ngIf="filteredGroups.length === 0 && !eventFeed.isLoading && !eventFeed.errorMessage">{{ emptyText }}</p>
        </section>
      </section>
    </aside>
  `,
  styles: [`
    :host,
    :host * { box-sizing: border-box; }

    .nf-root {
      position: fixed;
      right: 18px;
      bottom: 18px;
      z-index: 5000;
      pointer-events: none;
      color: #e5edf7;
      font-family: inherit;
    }

    .nf-toggle,
    .nf-panel { pointer-events: auto; }

    .nf-toggle {
      width: 230px;
      min-height: 52px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      padding: 9px 12px;
      border: 1px solid rgba(46, 230, 214, 0.32);
      border-radius: 16px;
      background: rgba(8, 13, 19, 0.96);
      color: #e5edf7;
      box-shadow: 0 14px 34px rgba(0, 0, 0, 0.34);
      cursor: pointer;
      text-align: left;
    }

    .nf-toggle-main { display: grid; gap: 3px; min-width: 0; }
    .nf-toggle-main b { color: #f8fafc; font-size: 13px; }
    .nf-toggle-main small { color: #94a3b8; font-size: 11px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .nf-toggle > strong {
      min-width: 32px;
      height: 30px;
      display: grid;
      place-items: center;
      border-radius: 10px;
      color: #99fff6;
      background: rgba(46, 230, 214, 0.14);
      font-variant-numeric: tabular-nums;
    }
    .nf-toggle > strong.is-muted { color: #94a3b8; background: rgba(148, 163, 184, 0.1); }

    .nf-panel {
      width: min(460px, calc(100vw - 32px));
      height: min(740px, calc(100dvh - 42px));
      display: flex;
      flex-direction: column;
      gap: 10px;
      padding: 12px;
      overflow: hidden;
      border: 1px solid rgba(148, 163, 184, 0.18);
      border-radius: 18px;
      background: #080d13;
      box-shadow: 0 22px 60px rgba(0, 0, 0, 0.42);
    }

    .nf-header {
      flex: 0 0 auto;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 12px;
      padding-bottom: 10px;
      border-bottom: 1px solid rgba(148, 163, 184, 0.12);
    }
    .nf-header span { color: #79f6e9; font-size: 11px; font-weight: 900; letter-spacing: 0.08em; text-transform: uppercase; }
    .nf-header h2 { margin: 4px 0 0; color: #f8fafc; font-size: 18px; line-height: 1.1; }
    .nf-close {
      width: 32px;
      height: 32px;
      display: grid;
      place-items: center;
      padding: 0;
      border: 1px solid rgba(148, 163, 184, 0.18);
      border-radius: 10px;
      background: rgba(255, 255, 255, 0.045);
      color: #cbd5e1;
      cursor: pointer;
      font-size: 20px;
    }

    .nf-summary {
      flex: 0 0 auto;
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 7px;
    }
    .nf-summary button {
      min-width: 0;
      min-height: 58px;
      display: grid;
      align-content: center;
      gap: 3px;
      padding: 8px;
      border: 1px solid rgba(148, 163, 184, 0.14);
      border-radius: 12px;
      background: rgba(255, 255, 255, 0.035);
      color: #e5edf7;
      text-align: left;
      cursor: pointer;
    }
    .nf-summary button.active { border-color: rgba(46, 230, 214, 0.38); background: rgba(46, 230, 214, 0.1); }
    .nf-summary b { color: #f8fafc; font-size: 20px; line-height: 1; font-variant-numeric: tabular-nums; }
    .nf-summary span { color: #94a3b8; font-size: 10px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

    .nf-toolbar { flex: 0 0 auto; display: grid; gap: 8px; }
    .nf-tabs,
    .nf-filters,
    .nf-actions { display: flex; gap: 6px; flex-wrap: wrap; }
    .nf-tabs button,
    .nf-filters button,
    .nf-actions button,
    .nf-state button {
      min-height: 30px;
      border: 1px solid rgba(148, 163, 184, 0.14);
      border-radius: 10px;
      background: rgba(255, 255, 255, 0.045);
      color: #cbd5e1;
      padding: 0 10px;
      font-size: 12px;
      font-weight: 800;
      cursor: pointer;
    }
    .nf-tabs button.active,
    .nf-filters button.active { color: #dffcf7; border-color: rgba(46, 230, 214, 0.36); background: rgba(46, 230, 214, 0.1); }
    .nf-toolbar input {
      width: 100%;
      height: 36px;
      min-height: 36px;
      border: 1px solid rgba(148, 163, 184, 0.16);
      border-radius: 12px;
      background: rgba(255, 255, 255, 0.045);
      color: #e5edf7;
      padding: 0 12px;
      outline: none;
    }
    .nf-actions { flex: 0 0 auto; }

    .nf-state {
      flex: 0 0 auto;
      margin: 0;
      padding: 9px 11px;
      border: 1px solid rgba(148, 163, 184, 0.14);
      border-radius: 12px;
      color: #cbd5e1;
      background: rgba(255, 255, 255, 0.035);
    }
    .nf-state.is-error { display: flex; justify-content: space-between; align-items: center; gap: 10px; border-color: rgba(248, 113, 113, 0.34); color: #fecaca; background: rgba(127, 29, 29, 0.16); }

    .nf-list {
      flex: 1 1 auto;
      min-height: 0;
      overflow-y: auto;
      overflow-x: hidden;
      display: flex;
      flex-direction: column;
      gap: 8px;
      padding-right: 4px;
    }
    .nf-list::-webkit-scrollbar { width: 8px; }
    .nf-list::-webkit-scrollbar-thumb { background: rgba(148, 163, 184, 0.22); border-radius: 99px; }

    .nf-group {
      flex: 0 0 auto;
      border: 1px solid rgba(148, 163, 184, 0.14);
      border-radius: 14px;
      background: rgba(255, 255, 255, 0.035);
      overflow: hidden;
    }
    .nf-group.critical,
    .nf-group.danger { border-color: rgba(248, 113, 113, 0.34); }
    .nf-group.high,
    .nf-group.warning { border-color: rgba(251, 191, 36, 0.28); }
    .nf-group.is-unread { box-shadow: inset 3px 0 0 rgba(46, 230, 214, 0.72); }

    .nf-group-head {
      width: 100%;
      min-height: 72px;
      display: grid;
      grid-template-columns: 44px minmax(0, 1fr) 54px;
      gap: 10px;
      align-items: center;
      padding: 10px;
      border: 0;
      background: transparent;
      color: #e5edf7;
      cursor: pointer;
      text-align: left;
    }
    .nf-severity {
      height: 30px;
      display: grid;
      place-items: center;
      border-radius: 10px;
      color: #a7fff6;
      background: rgba(46, 230, 214, 0.11);
      font-size: 10px;
      font-weight: 900;
      text-transform: uppercase;
    }
    .nf-group-body { display: grid; gap: 3px; min-width: 0; }
    .nf-group-body strong,
    .nf-group-body small,
    .nf-group-body em {
      display: block;
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .nf-group-body strong { color: #f8fafc; font-size: 13px; }
    .nf-group-body small { color: #94a3b8; font-size: 11px; }
    .nf-group-body em { color: #cbd5e1; font-size: 12px; font-style: normal; }
    .nf-group-count { display: grid; justify-items: end; gap: 3px; }
    .nf-group-count b { color: #f8fafc; font-size: 18px; font-variant-numeric: tabular-nums; }
    .nf-group-count i { color: #99fff6; font-size: 11px; font-style: normal; font-weight: 900; }
    .nf-group-count small { color: #94a3b8; font-size: 16px; }

    .nf-events {
      display: grid;
      gap: 6px;
      padding: 0 10px 10px 64px;
    }
    .nf-event {
      width: 100%;
      min-height: 64px;
      display: grid;
      gap: 4px;
      padding: 8px 10px;
      border: 1px solid rgba(148, 163, 184, 0.12);
      border-radius: 11px;
      background: rgba(2, 6, 12, 0.26);
      color: #e5edf7;
      cursor: pointer;
      text-align: left;
    }
    .nf-event.is-unread { border-color: rgba(46, 230, 214, 0.28); background: rgba(46, 230, 214, 0.07); }
    .nf-event span { display: flex; justify-content: space-between; gap: 10px; min-width: 0; }
    .nf-event strong,
    .nf-event small,
    .nf-event p,
    .nf-event em {
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .nf-event strong { color: #f8fafc; font-size: 12px; }
    .nf-event small,
    .nf-event em { color: #94a3b8; font-size: 11px; font-style: normal; }
    .nf-event p { margin: 0; color: #cbd5e1; font-size: 12px; }

    .nf-empty {
      margin: auto 0;
      padding: 22px 14px;
      border: 1px dashed rgba(148, 163, 184, 0.2);
      border-radius: 14px;
      color: #94a3b8;
      text-align: center;
      background: rgba(255, 255, 255, 0.025);
    }

    @media (max-width: 640px) {
      .nf-root { inset: auto 10px 76px 10px; right: 10px; bottom: 76px; }
      .nf-toggle { width: 100%; }
      .nf-panel { width: 100%; height: min(680px, calc(100dvh - 96px)); }
      .nf-summary { grid-template-columns: repeat(2, minmax(0, 1fr)); }
      .nf-group-head { grid-template-columns: 38px minmax(0, 1fr) 44px; }
      .nf-events { padding-left: 10px; }
    }
  `],
})
export class EventFeedPanelComponent {
  open = false;
  mode: EventFeedMode = 'notifications';
  openedGroups: Record<string, boolean> = {};
  searchTerm = '';
  priorityFilter: EventPriority | 'all' = 'all';
  unreadOnly = false;

  constructor(
    readonly eventFeed: EventFeedService,
    private readonly auth: AuthService,
    private readonly router: Router,
  ) {}

  get canSeeEvents(): boolean {
    const user = this.auth.getUser();

    return !!user && user.role !== 'observer';
  }

  get stats() {
    return this.eventFeed.getStats();
  }

  get groups(): EventGroup[] {
    return this.eventFeed.getGroups(this.mode);
  }

  get filteredGroups(): EventGroup[] {
    const search = this.searchTerm.trim().toLowerCase();

    return this.groups.filter((group) => {
      if (this.priorityFilter !== 'all' && group.priority !== this.priorityFilter) {
        return false;
      }

      if (this.unreadOnly && group.unreadCount === 0) {
        return false;
      }

      if (!search) return true;

      return group.items.some((event) => this.matchesSearch(event, search));
    });
  }

  get hasFilters(): boolean {
    return !!this.searchTerm.trim() || this.priorityFilter !== 'all' || this.unreadOnly;
  }

  get modeTitle(): string {
    if (this.mode === 'today') return 'Події сьогодні';
    if (this.mode === 'journal') return 'Журнал подій';
    return 'Центр повідомлень';
  }

  get modeEyebrow(): string {
    if (this.mode === 'journal') return 'Повна історія';
    if (this.mode === 'today') return 'Оперативна доба';
    return 'Згруповані важливі події';
  }

  get emptyText(): string {
    if (this.hasFilters) return 'За поточними фільтрами подій немає.';
    if (this.mode === 'notifications') return 'Нових важливих повідомлень немає.';
    if (this.mode === 'today') return 'Сьогодні подій немає.';
    return 'Журнал подій порожній.';
  }

  openPanel(): void {
    this.eventFeed.ensureLoaded();
    this.open = true;
  }

  setMode(mode: EventFeedMode): void {
    this.mode = mode;
    this.openedGroups = {};
    if (mode !== 'notifications') {
      this.unreadOnly = false;
    }
  }

  setPriorityFilter(priority: EventPriority | 'all'): void {
    this.priorityFilter = this.priorityFilter === priority ? 'all' : priority;
  }

  toggleUnreadOnly(): void {
    this.unreadOnly = !this.unreadOnly;
  }

  resetFilters(): void {
    this.searchTerm = '';
    this.priorityFilter = 'all';
    this.unreadOnly = false;
  }

  expandPriority(): void {
    this.filteredGroups.forEach((group) => {
      if (group.priority === 'critical' || group.priority === 'high' || group.unreadCount > 0) {
        this.openedGroups[group.key] = true;
      }
    });
  }

  collapseAll(): void {
    this.openedGroups = {};
  }

  markSeen(): void {
    this.eventFeed.markNotificationsSeen();
    this.unreadOnly = false;
  }

  close(event?: Event): void {
    event?.stopPropagation();
    this.open = false;
  }

  isOpen(key: string): boolean {
    return this.openedGroups[key] ?? false;
  }

  toggleGroup(key: string): void {
    this.openedGroups[key] = !this.isOpen(key);
  }

  priorityLabel(priority: EventPriority): string {
    if (priority === 'critical') return 'Крит';
    if (priority === 'high') return 'Вис';
    if (priority === 'normal') return 'Норм';
    return 'Низ';
  }

  trackGroup(_: number, group: EventGroup): string {
    return group.key;
  }

  trackEvent(_: number, event: EventLog): string {
    return event.id;
  }

  openEvent(event: EventLog): void {
    if (event.eventType === 'service_order') {
      void this.router.navigate(['/service-orders'], {
        queryParams: event.entityId ? { orderId: event.entityId, view: 'cards' } : undefined,
      });
      this.open = false;
      return;
    }

    if (event.eventType === 'weapon') {
      void this.router.navigate(['/weapon-systems'], {
        queryParams: event.entityId ? { entityId: event.entityId } : undefined,
      });
      this.open = false;
      return;
    }

    if (event.eventType === 'fire_position') {
      void this.router.navigate(['/fire-positions'], {
        queryParams: event.entityId ? { entityId: event.entityId } : undefined,
      });
      this.open = false;
      return;
    }

    if (event.eventType === 'stock') {
      void this.router.navigate(['/stock']);
      this.open = false;
      return;
    }

    if (event.eventType === 'air_threat') {
      void this.router.navigate(['/map']);
      this.open = false;
    }
  }

  private matchesSearch(event: EventLog, search: string): boolean {
    return [
      event.title,
      event.details,
      event.entityName,
      event.unitName,
      event.actorName,
      event.actorLogin,
      event.eventType,
      event.action,
    ]
      .filter(Boolean)
      .some((value) => String(value).toLowerCase().includes(search));
  }
}
